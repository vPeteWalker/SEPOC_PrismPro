#!/usr/bin/python

import sys
sys.path.insert(0, '/home/nutanix/ncc/bin')
import getopt
import env
import os
import requests

user=''
pwd=''

try:
  opts, args = getopt.getopt(sys.argv[1:], "u:p:", ["username=", "password="])
except getopt.GetoptError:
  print 'paintrigger.py -u <pc username> -p <pc password>'
  sys.exit(2)
for opt, arg in opts:
  if opt in ("-u", "username="):
    user=arg
  elif opt in ("-p", "password="):
    pwd=arg
# print 'paintrigger.py -u', user, ' -p', pwd

# resolve all alerts
requests.packages.urllib3.disable_warnings()
url = "https://localhost:9440/PrismGateway/services/rest/v2.0/alerts/resolve"
ret = requests.post(url, auth=(user, pwd), verify=False)
print ret

# execute policy check
os.system("python ~/ncc/bin/health_client.py --run_sync=True health_checks policy_checks all_policy_checks")
