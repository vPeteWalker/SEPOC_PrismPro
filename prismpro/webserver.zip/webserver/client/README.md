# ntnx-react-ui-app
[![CircleCI](https://phx-it-circleci-prod-1.eng.nutanix.com/gh/prism-ui/ntnx-react-ui-app/tree/master.svg?style=shield)](https://phx-it-circleci-prod-1.eng.nutanix.com/gh/prism-ui/ntnx-react-ui-app/tree/master)

This is the home for all React subapps that reside inside prism.

Tips:

1) `npm run test-watch -- --no-coverage` - This skips coverage and run only
new unit tests. Useful during dev since we have so many components.

2) Information about local i18n can be found in the `src/i18n/README.md`
