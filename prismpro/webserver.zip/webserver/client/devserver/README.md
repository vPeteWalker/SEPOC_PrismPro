### Running the Dev Server
From the `services` directory

`npm install`

`npm run devserver` - to run the dev server to actively view changes.

The dev server runs on port 3005. To test out a page just modify the src/devserver/index.js file to
load in the component you would like to view changes for. Currently it is loading in the xplay welcome
page.
