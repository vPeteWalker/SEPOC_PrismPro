//
// Copyright (c) 2018 Nutanix Inc. All rights reserved.
//

import MockDate from 'mockdate';

// Mon Oct 08 2018 17:36:18 GMT-0700 (Pacific Daylight Time)
MockDate.set(new Date(1539045378879));
