forever stopall
