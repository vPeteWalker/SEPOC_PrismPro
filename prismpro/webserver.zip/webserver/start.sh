npm install
forever start -al forever.log -o out.log -e err.log index.js
